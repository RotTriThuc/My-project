<head>
        <meta charset="UTF-8">
        <title>EvoLìfe - Phần mềm bản quyền</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <script src="https://kit.fontawesome.com/0dbd300604.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="animate.css">
</head>
