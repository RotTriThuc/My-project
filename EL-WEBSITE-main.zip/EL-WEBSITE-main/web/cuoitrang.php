<footer class="wow fadeIn">
<img src="images/logowhite.png" alt="Logo">
<hr>
        <section id="footerinf">
            <table>
                <tr>
                    <th rowspan=6 colspan=6>
                        <img id="imgcenter" src="air.jpg">
                        <p>
                            <h2>LIÊN HỆ</h2>
                            <a href="#"><i class="fa-solid fa-envelope" style="color: rgb(49, 255, 8);"></i> support@evolife.vn</a>
                            <br>&nbsp;
                            <br><a href="#"><i class="fa-solid fa-envelope" style="color: rgb(49, 255, 8);"></i> support@evolife.com</a>
                        </p>
                    </th>
                    <th rowspan=6 colspan=6>
                        <img id="imgcenter" src="air.jpg">
                        <p>
                            <h2>DỊCH VỤ</h2>
                            <a href="#"><i class="fa-solid fa-scroll" style="color: rgb(255, 238, 0);"></i> Chính Sách Bảo Mật</a>
                            <br>&nbsp;
                            <br><a href="#"><i class="fa-solid fa-book" style="color: rgb(255, 238, 0);"></i> Điều Khoản & Dịch Vụ</a>
                        </p>
                    </th>
                    <th rowspan=6 colspan=6>
                        <img id="imgcenter" src="air.jpg">
                        <p>
                            <h2>HOTLINE</h2>
                            <a href="#"><i class="fa-solid fa-phone" style="color: rgb(255, 17, 223);"></i> (+84) 123456789</a>
                            <br>&nbsp;
                            <br><a href="#"><i class="fa-solid fa-phone" style="color: rgb(255, 17, 235);"></i> (+84) 987654321</a>
                        </p>
                    </th>
                </tr>
            </table>
        </section>
        <hr>
		<h1>&copy; 2023 Nguyễn Bảo Dev</h1>
        <script src="wowanim/wow.min.js"></script>
        <script>
              new WOW().init();
        </script>
</footer>